package com.mycompany.ServiceOverview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
